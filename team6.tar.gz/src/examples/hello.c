#include <stdio.h>
#include <syscall.h>

int
main (int argc, char **argv)
{
 printf("hello pintos die die die\n");
  return EXIT_SUCCESS;
}
